package com.example.items

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
